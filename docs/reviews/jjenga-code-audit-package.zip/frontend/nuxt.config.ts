export default defineNuxtConfig({
  compatibilityDate: '2026-10-27',
  telemetry: false,
  devtools: { enabled: true },
  modules: ['@nuxt/ui', '@pinia/nuxt', '@nuxt/eslint'],
  css: ['~/assets/styles/main.css'],
  ui: { fonts: false },
  typescript: { strict: true },
  runtimeConfig: {
    public: {
      apiBaseUrl: 'http://127.0.0.1:8000/api/v1',
    },
  },
})
