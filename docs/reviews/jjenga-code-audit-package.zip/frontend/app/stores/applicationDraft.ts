/**
 * Application draft store — memory-only Pinia store for the application form.
 *
 * Holds guardian/learner fields, manages idempotency key lifecycle, and tracks
 * submission state. The draft is intentionally NOT persisted — refreshing or
 * closing the tab clears all personal details.
 *
 * Idempotency key rules:
 *   - A new key is generated when the payload changes.
 *   - The same key is reused when retrying an unchanged payload.
 *   - After confirmed submission, draft fields are cleared and a new key is ready.
 */
import { defineStore } from 'pinia'
import type { components } from '~/api/generated/types'

type SubmitRequest = components['schemas']['SubmitApplicationRequest']
type ReceiptResponse = components['schemas']['ApplicationReceiptResponse']
type GuardianRelationship = components['schemas']['GuardianRelationship']

/** Generates a random idempotency key (UUID v4). */
function generateKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.trunc(Math.random() * 16)
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

/** Creates a deterministic hash of the payload to detect changes. */
function hashPayload(fields: Omit<SubmitRequest, 'idempotency_key'>): string {
  return JSON.stringify(fields)
}

export interface ApplicationDraftState {
  /* Form fields */
  guardianName: string
  guardianEmail: string
  guardianPhone: string
  guardianRelationship: GuardianRelationship
  learnerName: string
  learnerAgeYears: number | null
  notes: string
  declarationAccepted: boolean

  /* Submission tracking */
  idempotencyKey: string
  lastPayloadHash: string
  submitting: boolean
  receipt: ReceiptResponse | null
  submissionError: string | null
}

export const useApplicationDraftStore = defineStore('applicationDraft', {
  state: (): ApplicationDraftState => ({
    guardianName: '',
    guardianEmail: '',
    guardianPhone: '',
    guardianRelationship: 'parent',
    learnerName: '',
    learnerAgeYears: null,
    notes: '',
    declarationAccepted: false,

    idempotencyKey: generateKey(),
    lastPayloadHash: '',
    submitting: false,
    receipt: null,
    submissionError: null,
  }),

  getters: {
    /**
     * Whether the form has any entered data worth preserving.
     * Used to show the "data lost on refresh" notice.
     */
    hasDraftData(): boolean {
      return !!(this.guardianName || this.guardianEmail || this.learnerName)
    },

    /** True when a confirmed receipt exists for the current session. */
    hasReceipt(): boolean {
      return this.receipt !== null
    },
  },

  actions: {
    /**
     * Builds the request payload from current form state.
     * Regenerates the idempotency key if the payload has changed since
     * the last build, preserving it for unchanged retries.
     */
    buildPayload(): SubmitRequest {
      const fields: Omit<SubmitRequest, 'idempotency_key'> = {
        guardian_name: this.guardianName.trim(),
        guardian_email: this.guardianEmail.trim(),
        guardian_phone: this.guardianPhone.trim() || null,
        guardian_relationship: this.guardianRelationship,
        learner_name: this.learnerName.trim(),
        learner_age_years: this.learnerAgeYears!,
        notes: this.notes.trim() || null,
        declaration_accepted: this.declarationAccepted,
        declaration_version: 1,
      }

      const hash = hashPayload(fields)
      if (hash !== this.lastPayloadHash) {
        this.idempotencyKey = generateKey()
        this.lastPayloadHash = hash
      }

      return { idempotency_key: this.idempotencyKey, ...fields }
    },

    /**
     * Records a successful submission receipt and clears personal details.
     * The receipt is kept in state so the confirmation screen can display it.
     */
    recordReceipt(receipt: ReceiptResponse) {
      this.receipt = receipt
      this.clearPersonalDetails()
    },

    /** Clears form fields but preserves the receipt for display. */
    clearPersonalDetails() {
      this.guardianName = ''
      this.guardianEmail = ''
      this.guardianPhone = ''
      this.guardianRelationship = 'parent'
      this.learnerName = ''
      this.learnerAgeYears = null
      this.notes = ''
      this.declarationAccepted = false
      this.lastPayloadHash = ''
      this.idempotencyKey = generateKey()
      this.submissionError = null
    },

    /** Fully resets the store, including the receipt. */
    resetAll() {
      this.clearPersonalDetails()
      this.receipt = null
    },
  },
})
