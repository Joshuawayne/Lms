/**
 * Lenis smooth scrolling plugin for the public website.
 *
 * Initialises Lenis on client-side mount, integrates with requestAnimationFrame,
 * and cleans up on route changes. Respects reduced-motion preferences —
 * when the user prefers reduced motion, Lenis is not initialised.
 */
import Lenis from 'lenis'

export default defineNuxtPlugin({
  name: 'lenis',
  enforce: 'post',
  setup() {
    if (import.meta.server) return

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (prefersReducedMotion) return

    let lenis: Lenis | null = null
    let rafId: number | null = null

    function raf(time: number) {
      lenis?.raf(time)
      rafId = requestAnimationFrame(raf)
    }

    function init() {
      lenis = new Lenis({
        duration: 1.2,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        touchMultiplier: 1.5,
      })
      rafId = requestAnimationFrame(raf)
    }

    function destroy() {
      if (rafId !== null) cancelAnimationFrame(rafId)
      lenis?.destroy()
      lenis = null
      rafId = null
    }

    init()

    const router = useRouter()
    router.afterEach(() => {
      /* Reset scroll position and re-sync Lenis after navigation */
      lenis?.scrollTo(0, { immediate: true })
    })

    /* Clean up on app unmount (HMR or full teardown) */
    const nuxtApp = useNuxtApp()
    nuxtApp.hook('app:beforeMount', () => {
      if (!lenis) init()
    })

    onNuxtReady(() => {
      if (!lenis) init()
    })

    /* Provide teardown for testing or manual cleanup */
    return {
      provide: {
        lenis: {
          instance: () => lenis,
          destroy,
        },
      },
    }
  },
})
