/**
 * AOS (Animate On Scroll) plugin for restrained entrance effects.
 *
 * Initialised client-side only with short fades, playing once.
 * Refreshes on route changes so dynamically loaded content animates correctly.
 * Respects reduced-motion via CSS (see main.css).
 */
import AOS from 'aos'

export default defineNuxtPlugin({
  name: 'aos',
  enforce: 'post',
  setup() {
    if (import.meta.server) return

    AOS.init({
      duration: 600,
      easing: 'ease-out-cubic',
      once: true,
      offset: 50,
      delay: 0,
      disable: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    })

    const router = useRouter()
    router.afterEach(() => {
      /* Allow DOM to settle after route change, then refresh AOS observers */
      setTimeout(() => AOS.refresh(), 300)
    })
  },
})
