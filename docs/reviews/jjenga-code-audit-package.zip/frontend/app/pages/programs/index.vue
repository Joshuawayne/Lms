<!--
  Program discovery page — /programs

  Lists published programs with pathway filtering and pagination.
  Consumes GET /api/v1/programs through the existing API client.
  Handles loading, empty, error and filtered-empty states.
-->
<script setup lang="ts">
import type { components } from '~/api/generated/types'
import { PATHWAY_FILTER_OPTIONS } from '~/features/programs/composables/pathwayInfo'

definePageMeta({ layout: 'public' })

useHead({
  title: 'Programs — Jjenga Code',
  meta: [
    { name: 'description', content: 'Browse Jjenga Code\'s coding and robotics programs for young people. Filter by school term, Saturday club or holiday pathway.' },
  ],
})

type Pathway = components['schemas']['Pathway']

const route = useRoute()
const router = useRouter()
const { $api } = useNuxtApp()

/* ── reactive query state ───────────────────────────────────────────── */
const selectedPathway = ref<Pathway | null>(
  (route.query.pathway as Pathway | undefined) ?? null,
)
const currentPage = ref(Number(route.query.page) || 1)
const pageSize = 9

/* ── fetch programs ─────────────────────────────────────────────────── */
const { data: response, status, error, refresh } = useAsyncData(
  () => {
    const params: Record<string, string | number> = {
      page: currentPage.value,
      page_size: pageSize,
    }
    if (selectedPathway.value) {
      params.pathway = selectedPathway.value
    }
    return $api<components['schemas']['ProgramListResponse']>('/programs', { params })
  },
  { watch: [selectedPathway, currentPage] },
)

/* ── sync URL with filter state ─────────────────────────────────────── */
watch([selectedPathway, currentPage], () => {
  const query: Record<string, string> = {}
  if (selectedPathway.value) query.pathway = selectedPathway.value
  if (currentPage.value > 1) query.page = String(currentPage.value)
  router.replace({ query })
})

function setPathway(pw: Pathway | null) {
  selectedPathway.value = pw
  currentPage.value = 1
}

function setPage(page: number) {
  currentPage.value = page
  /* Scroll to top of listing on page change */
  window.scrollTo({ top: 0, behavior: 'smooth' })
}
</script>

<template>
  <div>
    <!-- ── header ───────────────────────────────────────────────────── -->
    <section class="bg-navy-900 text-white relative overflow-hidden">
      <BlobShape class="absolute -top-16 right-10 opacity-10" size="300px" color="var(--color-purple-400)" />
      <div class="relative max-w-7xl mx-auto px-5 lg:px-8 py-16 md:py-20">
        <h1 class="text-3xl md:text-4xl font-heading font-extrabold mb-3" data-aos="fade-up">
          Our programs
        </h1>
        <p class="text-navy-300 text-lg max-w-xl" data-aos="fade-up" data-aos-delay="100">
          Find the right coding and robotics program for your child.
        </p>
      </div>
      <WaveDivider color="var(--color-navy-50)" />
    </section>

    <!-- ── catalogue ────────────────────────────────────────────────── -->
    <section class="section-gap bg-navy-50">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <!-- Pathway filter tabs -->
        <div class="flex flex-wrap gap-2 mb-10" data-aos="fade-up" role="tablist" aria-label="Filter programs by pathway">
          <button
            v-for="option in PATHWAY_FILTER_OPTIONS"
            :key="String(option.value)"
            role="tab"
            :aria-selected="selectedPathway === option.value"
            class="px-5 py-2 rounded-full text-sm font-medium transition-all duration-200"
            :class="selectedPathway === option.value
              ? 'bg-purple-600 text-white shadow-md'
              : 'bg-white text-navy-600 hover:bg-purple-50 border border-navy-200'"
            @click="setPathway(option.value)"
          >
            {{ option.label }}
          </button>
        </div>

        <!-- Loading skeleton -->
        <div v-if="status === 'pending'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div v-for="n in 6" :key="n" class="animate-pulse rounded-2xl bg-white border border-navy-100 overflow-hidden">
            <div class="h-2 bg-navy-100" />
            <div class="p-6 space-y-4">
              <div class="h-4 bg-navy-100 rounded w-1/3" />
              <div class="h-6 bg-navy-100 rounded w-3/4" />
              <div class="h-4 bg-navy-100 rounded w-full" />
              <div class="h-4 bg-navy-100 rounded w-2/3" />
              <div class="h-8 bg-navy-50 rounded-full w-1/2 mt-4" />
            </div>
          </div>
        </div>

        <!-- Error state -->
        <div v-else-if="error" class="text-center py-16">
          <UIcon name="i-lucide-alert-triangle" class="w-12 h-12 text-pink-500 mx-auto mb-4" />
          <h2 class="font-heading font-bold text-navy-800 text-xl mb-2">Unable to load programs</h2>
          <p class="text-navy-500 mb-6">Something went wrong. Please try again.</p>
          <UButton class="bg-purple-600 hover:bg-purple-700 text-white rounded-full px-6" @click="refresh()">
            Retry
          </UButton>
        </div>

        <!-- Empty state -->
        <div v-else-if="response && response.items.length === 0" class="text-center py-16">
          <UIcon name="i-lucide-folder-open" class="w-12 h-12 text-navy-300 mx-auto mb-4" />
          <h2 class="font-heading font-bold text-navy-800 text-xl mb-2">
            {{ selectedPathway ? 'No programs in this pathway' : 'No programs available' }}
          </h2>
          <p class="text-navy-500 mb-6">
            {{ selectedPathway ? 'Try viewing all programs or a different pathway.' : 'Check back soon for new programs.' }}
          </p>
          <UButton v-if="selectedPathway" class="bg-purple-600 hover:bg-purple-700 text-white rounded-full px-6" @click="setPathway(null)">
            View all programs
          </UButton>
        </div>

        <!-- Program grid -->
        <template v-else-if="response && response.items.length > 0">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ProgramCard
              v-for="program in response.items"
              :key="program.id"
              :program="program"
              data-aos="fade-up"
            />
          </div>

          <!-- Pagination -->
          <div v-if="response.total_pages > 1" class="flex justify-center items-center gap-2 mt-12">
            <UButton
              :disabled="currentPage <= 1"
              variant="outline"
              class="rounded-full"
              @click="setPage(currentPage - 1)"
            >
              <UIcon name="i-lucide-chevron-left" class="w-4 h-4" />
            </UButton>

            <template v-for="page in response.total_pages" :key="page">
              <UButton
                :class="page === currentPage
                  ? 'bg-purple-600 text-white'
                  : 'bg-white text-navy-600 hover:bg-purple-50 border border-navy-200'"
                class="rounded-full min-w-[2.5rem]"
                @click="setPage(page)"
              >
                {{ page }}
              </UButton>
            </template>

            <UButton
              :disabled="currentPage >= response.total_pages"
              variant="outline"
              class="rounded-full"
              @click="setPage(currentPage + 1)"
            >
              <UIcon name="i-lucide-chevron-right" class="w-4 h-4" />
            </UButton>
          </div>
        </template>
      </div>
    </section>
  </div>
</template>
