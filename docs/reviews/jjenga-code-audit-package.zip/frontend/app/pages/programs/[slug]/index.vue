<!--
  Program detail page — /programs/:slug

  Fetches a single program by slug using GET /api/v1/programs/:slug.
  Displays full description, dates, eligibility and a prominent CTA
  to apply when the application window is open.
-->
<script setup lang="ts">
import type { components } from '~/api/generated/types'
import { getPathwayInfo } from '~/features/programs/composables/pathwayInfo'
import { useApplicationAvailability } from '~/features/programs/composables/useApplicationAvailability'

definePageMeta({ layout: 'public' })

const route = useRoute()
const { $api } = useNuxtApp()
const slug = computed(() => route.params.slug as string)

const { data: program, status, error } = useAsyncData(
  `program-${slug.value}`,
  () => $api<components['schemas']['ProgramDetailResponse']>(`/programs/${slug.value}`),
)

const pathway = computed(() => program.value ? getPathwayInfo(program.value.pathway) : null)
const availability = computed(() => useApplicationAvailability(program.value))

useHead({
  title: computed(() => program.value ? `${program.value.title} — Jjenga Code` : 'Program — Jjenga Code'),
  meta: [
    { name: 'description', content: computed(() => program.value?.summary ?? 'Program details at Jjenga Code.') },
  ],
})

function formatDate(iso: string | null): string {
  if (!iso) return 'To be announced'
  return new Date(iso).toLocaleDateString('en-KE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
}
</script>

<template>
  <div>
    <!-- ── Loading skeleton ─────────────────────────────────────────── -->
    <template v-if="status === 'pending'">
      <section class="bg-navy-900 text-white">
        <div class="max-w-7xl mx-auto px-5 lg:px-8 py-16">
          <div class="animate-pulse space-y-4 max-w-2xl">
            <div class="h-4 bg-navy-700 rounded w-1/4" />
            <div class="h-10 bg-navy-700 rounded w-3/4" />
            <div class="h-5 bg-navy-700 rounded w-full" />
          </div>
        </div>
        <WaveDivider color="white" />
      </section>
    </template>

    <!-- ── Error / not found ────────────────────────────────────────── -->
    <template v-else-if="error">
      <section class="bg-navy-900 text-white">
        <div class="max-w-7xl mx-auto px-5 lg:px-8 py-16">
          <h1 class="text-3xl font-heading font-bold mb-3">Program not found</h1>
          <p class="text-navy-300 mb-6">This program may no longer be published or the link may be incorrect.</p>
          <NuxtLink to="/programs">
            <UButton class="bg-yellow-400 hover:bg-yellow-300 text-navy-900 rounded-full px-6">
              Browse all programs
            </UButton>
          </NuxtLink>
        </div>
        <WaveDivider color="white" />
      </section>
    </template>

    <!-- ── Program content ──────────────────────────────────────────── -->
    <template v-else-if="program">
      <!-- Header -->
      <section class="bg-navy-900 text-white relative overflow-hidden">
        <BlobShape class="absolute -top-16 right-10 opacity-10" size="350px" :color="pathway?.color ?? 'var(--color-purple-400)'" />
        <div class="relative max-w-7xl mx-auto px-5 lg:px-8 py-16 md:py-20">
          <!-- Breadcrumb -->
          <nav aria-label="Breadcrumb" class="mb-6" data-aos="fade-up">
            <ol class="flex items-center gap-2 text-sm text-navy-400">
              <li><NuxtLink to="/programs" class="hover:text-yellow-400 transition-colors">Programs</NuxtLink></li>
              <li><UIcon name="i-lucide-chevron-right" class="w-3.5 h-3.5" /></li>
              <li class="text-navy-200">{{ program.title }}</li>
            </ol>
          </nav>

          <!-- Pathway badge -->
          <div class="flex items-center gap-2 mb-4" data-aos="fade-up">
            <UIcon :name="pathway?.icon ?? 'i-lucide-book-open'" class="w-4 h-4 text-yellow-400" />
            <span class="text-sm font-semibold text-yellow-400 uppercase tracking-wider">{{ pathway?.label }}</span>
          </div>

          <h1 class="text-3xl md:text-4xl lg:text-5xl font-heading font-extrabold mb-4" data-aos="fade-up" data-aos-delay="100">
            {{ program.title }}
          </h1>
          <p class="text-lg text-navy-300 max-w-2xl" data-aos="fade-up" data-aos-delay="200">
            {{ program.summary }}
          </p>
        </div>
        <WaveDivider color="white" />
      </section>

      <!-- Body -->
      <section class="section-gap bg-white">
        <div class="max-w-7xl mx-auto px-5 lg:px-8">
          <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Main content -->
            <div class="lg:col-span-2 space-y-8">
              <div data-aos="fade-up">
                <h2 class="text-2xl font-heading font-bold text-navy-800 mb-4">About this program</h2>
                <div class="prose-narrow text-navy-600 leading-relaxed whitespace-pre-line text-base">
                  {{ program.description || program.summary }}
                </div>
              </div>
            </div>

            <!-- Sidebar -->
            <aside class="space-y-6" data-aos="fade-up" data-aos-delay="100">
              <!-- Details card -->
              <div class="rounded-2xl border border-navy-100 p-6 space-y-4 bg-navy-50">
                <h3 class="font-heading font-bold text-navy-800">Program details</h3>

                <div class="space-y-3 text-sm text-navy-600">
                  <div class="flex items-start gap-3">
                    <UIcon name="i-lucide-calendar" class="w-5 h-5 text-purple-500 mt-0.5 shrink-0" />
                    <div>
                      <p class="font-medium text-navy-700">Dates</p>
                      <p>{{ formatDate(program.starts_on) }}</p>
                      <p v-if="program.ends_on" class="text-navy-400">to {{ formatDate(program.ends_on) }}</p>
                    </div>
                  </div>

                  <div v-if="program.min_age_years || program.max_age_years" class="flex items-start gap-3">
                    <UIcon name="i-lucide-users" class="w-5 h-5 text-purple-500 mt-0.5 shrink-0" />
                    <div>
                      <p class="font-medium text-navy-700">Ages</p>
                      <p>{{ program.min_age_years ?? '?' }} – {{ program.max_age_years ?? '?' }} years</p>
                    </div>
                  </div>

                  <div class="flex items-start gap-3">
                    <UIcon name="i-lucide-map-pin" class="w-5 h-5 text-purple-500 mt-0.5 shrink-0" />
                    <div>
                      <p class="font-medium text-navy-700">Format</p>
                      <p>{{ program.delivery === 'in_person' ? 'In person' : program.delivery === 'online' ? 'Online' : 'Hybrid' }}</p>
                    </div>
                  </div>

                  <div v-if="program.max_enrolments" class="flex items-start gap-3">
                    <UIcon name="i-lucide-ticket" class="w-5 h-5 text-purple-500 mt-0.5 shrink-0" />
                    <div>
                      <p class="font-medium text-navy-700">Places</p>
                      <p>{{ program.max_enrolments }} maximum</p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Application CTA -->
              <div
                class="rounded-2xl border-2 p-6"
                :class="{
                  'border-green-200 bg-green-50': availability.status === 'open',
                  'border-yellow-200 bg-yellow-50': availability.status === 'not_yet',
                  'border-navy-100 bg-navy-50': availability.status === 'closed' || availability.status === 'disabled',
                }"
              >
                <div class="flex items-center gap-2 mb-3">
                  <span
                    class="w-2 h-2 rounded-full"
                    :class="{
                      'bg-green-500': availability.status === 'open',
                      'bg-yellow-500': availability.status === 'not_yet',
                      'bg-navy-300': availability.status === 'closed' || availability.status === 'disabled',
                    }"
                  />
                  <span
                    class="text-sm font-semibold"
                    :class="{
                      'text-green-700': availability.status === 'open',
                      'text-yellow-700': availability.status === 'not_yet',
                      'text-navy-500': availability.status === 'closed' || availability.status === 'disabled',
                    }"
                  >
                    {{ availability.label }}
                  </span>
                </div>

                <NuxtLink v-if="availability.canApply" :to="`/programs/${program.slug}/apply`">
                  <UButton size="lg" block class="bg-purple-600 hover:bg-purple-700 text-white rounded-full font-semibold">
                    Apply now
                  </UButton>
                </NuxtLink>

                <p v-else class="text-sm text-navy-500">
                  <template v-if="availability.status === 'not_yet'">
                    You'll be able to apply once the application window opens.
                  </template>
                  <template v-else-if="availability.status === 'closed'">
                    The application window for this program has closed.
                  </template>
                  <template v-else>
                    Applications are not currently available for this program.
                  </template>
                </p>
              </div>

              <!-- Back link -->
              <NuxtLink to="/programs" class="inline-flex items-center gap-1 text-sm text-purple-600 hover:text-purple-700 font-medium transition-colors">
                <UIcon name="i-lucide-arrow-left" class="w-4 h-4" />
                All programs
              </NuxtLink>
            </aside>
          </div>
        </div>
      </section>
    </template>
  </div>
</template>
