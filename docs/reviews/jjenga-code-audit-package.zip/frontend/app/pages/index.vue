<!--
  Jjenga Code — Public Homepage
  Directly reflects the visual identity of the Jjenga Code posters:
  - Bright white surfaces with subtle repeating pixel pattern background.
  - Heavy navy headlines with deliberate line breaks ("Raise a builder, not just a user.")
  - Warm gradients, pink/purple/yellow accents, and expressive SVG shapes.
  - Curated high-resolution CDN photography with proper attribution.
  - Full pathway coverage, pedagogical breakdown, parent reassurance,
    confirmed November 2026 camp highlight, and honest application journey.
-->
<script setup lang="ts">
import { BRAND_IMAGES } from '~/utils/images'

import type { BrandImage } from '~/utils/images'

definePageMeta({ layout: 'public' })

useHead({
  title: 'Jjenga Code — Raise a Builder, Not Just a User',
  meta: [
    {
      name: 'description',
      content: 'Hands-on coding and robotics where children ask questions, test ideas, and build something of their own. School-term programs, Saturday clubs, and holiday camps in Nairobi.',
    },
    { property: 'og:title', content: 'Jjenga Code — Raise a Builder, Not Just a User' },
    { property: 'og:description', content: 'Hands-on coding and robotics for young makers in Nairobi, Kenya.' },
    { property: 'og:image', content: BRAND_IMAGES.hero.url },
  ],
})

interface PathwayItem {
  key: string
  title: string
  schedule: string
  description: string
  image: BrandImage
  badgeColor: string
  accentBorder: string
  query: string
}

interface ProjectArea {
  id: string
  title: string
  tagline: string
  description: string
  image: BrandImage
  tags: string[]
}

// Pathways configuration
const pathways: PathwayItem[] = [
  {
    key: 'school_term',
    title: 'School-Term Programs',
    schedule: 'Weekly sessions throughout the term',
    description: 'Weekly coding and robotics sessions during the school term. Learners build structured projects, solve real problems, and graduate with a portfolio of completed work.',
    image: BRAND_IMAGES.school_term,
    badgeColor: 'border-purple-200 bg-purple-50 text-purple-700',
    accentBorder: 'hover:border-purple-500',
    query: 'school_term',
  },
  {
    key: 'saturday_club',
    title: 'Saturday Coding Club',
    schedule: 'Every Saturday morning (9am – 12pm)',
    description: 'A vibrant weekend community of young builders. Drop in, tinker with electronics, code interactive games, and collaborate with like-minded friends.',
    image: BRAND_IMAGES.saturday_club,
    badgeColor: 'border-yellow-200 bg-yellow-50 text-yellow-800',
    accentBorder: 'hover:border-yellow-500',
    query: 'saturday_club',
  },
  {
    key: 'holiday',
    title: 'Holiday Programs & Camps',
    schedule: '5-Day immersive holiday intensives',
    description: 'Intensive full-day camps during school holidays. Learners tackle a thematic challenge from initial concept to a functioning robotic prototype or software game.',
    image: BRAND_IMAGES.holiday_camp,
    badgeColor: 'border-pink-200 bg-pink-50 text-pink-700',
    accentBorder: 'hover:border-pink-500',
    query: 'holiday',
  },
]

// What young builders explore & make
const projectAreas: ProjectArea[] = [
  {
    id: 'robotics',
    title: 'Robotics & Hardware',
    tagline: 'From sensors to moving machines',
    description: 'Learners connect motors, ultrasonic distance sensors, and microcontrollers. They write real code to make machines respond to their environment.',
    image: BRAND_IMAGES.making_robotics,
    tags: ['Micro:bit', 'Arduino', 'Sensors & Motors', 'Autonomous Vehicles'],
  },
  {
    id: 'coding',
    title: 'Game Development & Logic',
    tagline: 'Turn playtime into creative programming',
    description: 'Understanding loops, conditionals, and algorithms by constructing playable games, interactive stories, and multiplayer simulations.',
    image: BRAND_IMAGES.holiday_camp,
    tags: ['Visual Block Coding', 'Python Fundamentals', '2D Game Physics', 'Logic & Loops'],
  },
  {
    id: 'electronics',
    title: 'Physical Computing',
    tagline: 'Bring ideas into the physical world',
    description: 'Hands-on breadboard prototyping, circuit design, LED matrix controls, and smart home inventions that bridge software and hardware.',
    image: BRAND_IMAGES.electronics,
    tags: ['Breadboards', 'LED Matrices', 'Circuits & Power', 'IoT Prototypes'],
  },
]

const activeArea = ref<ProjectArea>(projectAreas[0]!)

// How learning works steps
const learningSteps = [
  {
    number: '01',
    title: 'Hands-on Exploration',
    subtext: 'Try it. Change it. Try again.',
    description: 'We skip dry lectures. Learners immediately engage with tangible kits, starter code, and curiosity-driven puzzles designed to spark discovery.',
  },
  {
    number: '02',
    title: 'Purposeful Project Building',
    subtext: "From 'what if?' to 'I made this.'",
    description: 'Every concept is anchored in a concrete project. Learners design and code artifacts that solve real challenges or bring their imaginations to life.',
  },
  {
    number: '03',
    title: 'Personalized Mentor Guidance',
    subtext: 'Safe support when code fails.',
    description: 'Experienced educators maintain a supportive teacher-to-learner ratio, debugging together, encouraging agency, and celebrating breakthrough moments.',
  },
  {
    number: '04',
    title: 'Reflection & Portfolio Growth',
    subtext: 'Demonstrable skill progression.',
    description: 'Learners articulate how their creation functions. We track real project performance, competencies, and problem-solving values across terms.',
  },
]

// The 4 Application stages
const applicationStages = [
  {
    step: '1',
    title: 'Select Program',
    desc: 'Browse published schedules and pick the right fit for your child’s age and interests.',
  },
  {
    step: '2',
    title: 'Submit Application',
    desc: 'Fill out our secure guardian and learner application. No pre-existing account required.',
  },
  {
    step: '3',
    title: 'Team Review',
    desc: 'Our academic team reviews age eligibility, class group balance, and seat availability.',
  },
  {
    step: '4',
    title: 'Enrolment & Welcome',
    desc: 'Upon approval, you receive a confirmed enrolment notice and your personal portal invitation.',
  },
]

// Confirmed FAQs
const faqs = [
  {
    q: 'Does my child need previous coding or robotics experience?',
    a: 'Not at all. Our programs cater to beginners through to experienced young coders. Mentors adapt project complexity to each child’s individual starting point.',
  },
  {
    q: 'What equipment does my child need to bring?',
    a: 'We provide all hardware kits, microcontrollers, robotics parts, breadboards, and testing equipment. Learners are welcome to bring their own laptop, or use our lab devices upon advance request.',
  },
  {
    q: 'Where will the November 2026 Holiday Camp take place?',
    a: 'The upcoming 5-day holiday camp runs Monday to Friday, 9:00 AM – 5:00 PM at Maktaba Kuu, Upper Hill, Nairobi.',
  },
  {
    q: 'Does submitting an application guarantee a reserved seat?',
    a: 'Your submission generates a unique receipt reference that confirms our database has recorded your application. To ensure optimal mentor-to-student ratios, placements are formally confirmed following our team’s admissions review.',
  },
  {
    q: 'How do you keep parents informed of their child’s progress?',
    a: 'Mentors record routine project observations and competency evidence. In our upcoming portal, authorized guardians can view constructive feedback, projects, and milestone reports directly.',
  },
]
</script>

<template>
  <div class="relative bg-white selection:bg-pink-100 selection:text-navy-950">
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 1. HERO SECTION                                                     -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section class="relative overflow-hidden poster-pattern pt-8 pb-16 md:py-20 lg:py-24 border-b border-navy-100">
      <!-- Faint background geometric letterings -->
      <div class="absolute inset-0 pointer-events-none select-none overflow-hidden opacity-[0.035] flex items-center justify-center font-heading font-black text-[22vw] text-navy-950 tracking-tighter leading-none" aria-hidden="true">
        BUILD
      </div>

      <div class="relative max-w-7xl mx-auto px-5 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          <!-- Left column: Bold navy headlines and call to action -->
          <div class="lg:col-span-7 space-y-6">
            <div data-aos="fade-up" class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-pink-200 bg-pink-50/80 text-pink-700 text-xs font-semibold tracking-wide uppercase">
              <span class="w-2 h-2 rounded-full bg-pink-500 animate-pulse" />
              Creative STEM Education in Nairobi
            </div>

            <h1 data-aos="fade-up" data-aos-delay="100" class="text-4xl sm:text-5xl md:text-6xl font-heading font-black text-navy-950 tracking-tight leading-[1.08]">
              Raise a builder,<br>
              <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-pink-600 to-yellow-500">
                not just a user.
              </span>
            </h1>

            <p data-aos="fade-up" data-aos-delay="150" class="text-lg md:text-xl text-navy-700 max-w-xl font-normal leading-relaxed">
              Hands-on coding and robotics where children ask questions, test bold ideas, and build real projects of their own.
            </p>

            <!-- Key value pill row -->
            <div data-aos="fade-up" data-aos-delay="200" class="flex flex-wrap items-center gap-4 text-xs font-medium text-navy-600 pt-1">
              <div class="flex items-center gap-1.5">
                <UIcon name="i-lucide-check-circle" class="w-4 h-4 text-purple-600" />
                <span>Ages 7 to 17</span>
              </div>
              <div class="flex items-center gap-1.5">
                <UIcon name="i-lucide-check-circle" class="w-4 h-4 text-purple-600" />
                <span>Small Mentor Ratios</span>
              </div>
              <div class="flex items-center gap-1.5">
                <UIcon name="i-lucide-check-circle" class="w-4 h-4 text-purple-600" />
                <span>Real Hardware &amp; Code</span>
              </div>
            </div>

            <!-- Actions -->
            <div data-aos="fade-up" data-aos-delay="250" class="flex flex-wrap items-center gap-4 pt-3">
              <NuxtLink to="/programs">
                <UButton
                  size="xl"
                  class="bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-full px-8 py-3.5 shadow-md hover:shadow-lg transition-all"
                >
                  Explore programs
                  <UIcon name="i-lucide-arrow-right" class="w-5 h-5 ml-1" />
                </UButton>
              </NuxtLink>
              <a href="#how-learning-works">
                <UButton
                  size="xl"
                  variant="outline"
                  class="border-navy-200 text-navy-800 hover:bg-navy-50 font-medium rounded-full px-7 py-3.5 transition-all"
                >
                  See how learning works
                </UButton>
              </a>
            </div>

            <!-- Quote/motto cue -->
            <p data-aos="fade-up" data-aos-delay="300" class="text-xs text-navy-500 italic pt-2">
              “From ‘what if?’ to ‘I made this.’”
            </p>
          </div>

          <!-- Right column: Photographic composition with hand-drawn accents -->
          <div class="lg:col-span-5 relative" data-aos="fade-left" data-aos-delay="200">
            <!-- Decorative colored backdrop shapes -->
            <div class="absolute -top-6 -right-6 w-72 h-72 bg-yellow-200/40 rounded-full blur-2xl -z-10" />
            <div class="absolute -bottom-8 -left-8 w-80 h-80 bg-purple-200/40 rounded-full blur-2xl -z-10" />

            <!-- Main photograph frame -->
            <div class="relative rounded-3xl overflow-hidden border-4 border-white shadow-2xl bg-navy-50 aspect-[4/3] sm:aspect-[5/4] lg:aspect-[4/5]">
              <img
                :src="BRAND_IMAGES.hero.url"
                :alt="BRAND_IMAGES.hero.alt"
                width="800"
                height="1000"
                class="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                loading="eager"
                fetchpriority="high"
              >

              <!-- Gradient overlay at the base for contrast -->
              <div class="absolute inset-0 bg-gradient-to-t from-navy-950/70 via-transparent to-transparent pointer-events-none" />

              <!-- Overlay badge at bottom -->
              <div class="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-lg border border-navy-100 flex items-center justify-between">
                <div>
                  <span class="block text-xs font-semibold uppercase tracking-wider text-purple-700">Hands-on Robotics</span>
                  <p class="text-sm font-bold text-navy-900">Minds engaged, circuits connected.</p>
                </div>
                <div class="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center text-navy-950 font-bold shrink-0">
                  <UIcon name="i-lucide-cpu" class="w-5 h-5" />
                </div>
              </div>
            </div>

            <!-- Floating retro accent card -->
            <div class="absolute -top-4 -left-4 bg-navy-900 text-white rounded-2xl px-4 py-2.5 shadow-xl border border-navy-700 flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-green-400 animate-ping" />
              <span class="text-xs font-mono font-medium">Try it. Change it. Try again.</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 2. CONFIRMED CAMP SPOTLIGHT (November 2026)                          -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section class="bg-gradient-to-r from-navy-900 via-navy-950 to-purple-950 text-white py-12 relative overflow-hidden border-b border-navy-800">
      <div class="max-w-7xl mx-auto px-5 lg:px-8 relative z-10">
        <div class="rounded-3xl bg-white/5 border border-white/10 p-6 md:p-8 backdrop-blur-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div class="lg:col-span-8 space-y-3">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-400 text-navy-950 text-xs font-bold uppercase tracking-wider">
              <UIcon name="i-lucide-flame" class="w-4 h-4" />
              Upcoming Camp Feature
            </div>
            <h2 class="text-2xl sm:text-3xl font-heading font-black text-white">
              5-Day Coding &amp; Robotics Camp — November 2026
            </h2>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 text-sm text-navy-200">
              <div class="flex items-center gap-2">
                <UIcon name="i-lucide-calendar" class="w-5 h-5 text-yellow-400 shrink-0" />
                <span>23–27 November 2026</span>
              </div>
              <div class="flex items-center gap-2">
                <UIcon name="i-lucide-clock" class="w-5 h-5 text-yellow-400 shrink-0" />
                <span>Mon–Fri, 9:00 AM – 5:00 PM</span>
              </div>
              <div class="flex items-center gap-2">
                <UIcon name="i-lucide-map-pin" class="w-5 h-5 text-pink-400 shrink-0" />
                <span>Maktaba Kuu, Upper Hill</span>
              </div>
            </div>
          </div>
          <div class="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3 justify-center">
            <NuxtLink to="/programs/coding-robotics-camp-nov-2026" class="w-full">
              <UButton size="lg" block class="bg-yellow-400 hover:bg-yellow-300 text-navy-950 font-bold rounded-full py-3">
                View Camp Details &amp; Apply
              </UButton>
            </NuxtLink>
            <span class="text-xs text-center text-navy-300">
              Applications are currently open for ages 7–17.
            </span>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 3. THREE LEARNING PATHWAYS                                         -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section class="py-20 lg:py-28 bg-white border-b border-navy-100">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span class="inline-block text-xs font-bold tracking-widest text-purple-700 uppercase bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Continuous Learning Pathways
          </span>
          <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
            A pathway for every young maker’s journey.
          </h2>
          <p class="text-base text-navy-600">
            Whether during the school term, on Saturday mornings, or during school holidays, learners build practical skills in an inspiring environment.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div
            v-for="pathway in pathways"
            :key="pathway.key"
            data-aos="fade-up"
            class="group rounded-3xl bg-white border-2 border-navy-100/80 hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden"
            :class="pathway.accentBorder"
          >
            <!-- Pathway image -->
            <div class="relative h-56 overflow-hidden bg-navy-100">
              <img
                :src="pathway.image.url"
                :alt="pathway.image.alt"
                width="600"
                height="400"
                class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              >
              <div class="absolute top-4 left-4">
                <span class="px-3 py-1 rounded-full text-xs font-bold border backdrop-blur-md" :class="pathway.badgeColor">
                  {{ pathway.schedule }}
                </span>
              </div>
            </div>

            <!-- Content -->
            <div class="p-6 md:p-8 flex-1 flex flex-col justify-between space-y-4">
              <div class="space-y-2">
                <h3 class="text-xl font-heading font-bold text-navy-950 group-hover:text-purple-700 transition-colors">
                  {{ pathway.title }}
                </h3>
                <p class="text-sm text-navy-600 leading-relaxed">
                  {{ pathway.description }}
                </p>
              </div>

              <div class="pt-4 border-t border-navy-50">
                <NuxtLink
                  :to="`/programs?pathway=${pathway.query}`"
                  class="inline-flex items-center text-sm font-bold text-purple-600 group-hover:text-purple-700 group-hover:translate-x-1 transition-all"
                >
                  Browse {{ pathway.title }}
                  <UIcon name="i-lucide-arrow-right" class="w-4 h-4 ml-1" />
                </NuxtLink>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 4. WHAT YOUNG BUILDERS EXPLORE & MAKE                               -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section class="py-20 lg:py-28 bg-navy-50/60 border-b border-navy-100">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <div class="max-w-3xl mx-auto text-center mb-14 space-y-3">
          <span class="text-xs font-bold text-pink-600 uppercase tracking-widest bg-pink-50 px-3 py-1 rounded-full border border-pink-200">
            Real Skills &amp; Tangible Creations
          </span>
          <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
            What will your child build next?
          </h2>
          <p class="text-base text-navy-600">
            We don’t just teach syntax. Learners combine software, electronics, and creative design to construct working inventions.
          </p>
        </div>

        <!-- Interactive tab switcher -->
        <div class="flex justify-center gap-3 mb-10 overflow-x-auto pb-2">
          <button
            v-for="area in projectAreas"
            :key="area.id"
            class="px-5 py-2.5 rounded-full text-sm font-semibold transition-all whitespace-nowrap focus-visible:outline-2 focus-visible:outline-purple-600"
            :class="activeArea.id === area.id ? 'bg-navy-900 text-white shadow-md' : 'bg-white text-navy-700 hover:bg-navy-100 border border-navy-200'"
            @click="activeArea = area"
          >
            {{ area.title }}
          </button>
        </div>

        <!-- Showcase display -->
        <div class="rounded-3xl bg-white border border-navy-200/80 shadow-lg overflow-hidden p-6 md:p-10">
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div class="lg:col-span-6 space-y-4">
              <span class="text-xs font-bold uppercase tracking-wider text-purple-600">
                {{ activeArea.tagline }}
              </span>
              <h3 class="text-2xl sm:text-3xl font-heading font-black text-navy-950">
                {{ activeArea.title }}
              </h3>
              <p class="text-base text-navy-700 leading-relaxed">
                {{ activeArea.description }}
              </p>

              <!-- Tags -->
              <div class="pt-3">
                <span class="block text-xs font-semibold text-navy-500 uppercase tracking-wider mb-2">Key Areas:</span>
                <div class="flex flex-wrap gap-2">
                  <span
                    v-for="tag in activeArea.tags"
                    :key="tag"
                    class="px-3 py-1 rounded-lg text-xs font-medium bg-purple-50 text-purple-700 border border-purple-100"
                  >
                    {{ tag }}
                  </span>
                </div>
              </div>
            </div>

            <div class="lg:col-span-6">
              <div class="rounded-2xl overflow-hidden aspect-[4/3] bg-navy-100 border-2 border-navy-100 shadow-inner">
                <img
                  :src="activeArea.image.url"
                  :alt="activeArea.image.alt"
                  width="700"
                  height="500"
                  class="w-full h-full object-cover"
                  loading="lazy"
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 5. HOW PRACTICAL LEARNING WORKS                                     -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section id="how-learning-works" class="py-20 lg:py-28 bg-white border-b border-navy-100">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span class="inline-block text-xs font-bold tracking-widest text-yellow-800 uppercase bg-yellow-100 px-3 py-1 rounded-full border border-yellow-200">
            Our Learning Philosophy
          </span>
          <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
            How learning, practice and reflection fit together.
          </h2>
          <p class="text-base text-navy-600">
            We move learners from passive consumers to active creators through a structured cycle of curiosity, guided building, and supportive feedback.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div
            v-for="step in learningSteps"
            :key="step.number"
            data-aos="fade-up"
            class="rounded-3xl p-6 bg-navy-50/50 border border-navy-100 hover:border-purple-300 transition-colors flex flex-col justify-between space-y-4"
          >
            <div>
              <span class="block text-4xl font-mono font-black text-purple-300 mb-2">
                {{ step.number }}
              </span>
              <h3 class="text-lg font-heading font-bold text-navy-950 mb-1">
                {{ step.title }}
              </h3>
              <p class="text-xs font-bold text-purple-700 italic mb-3">
                “{{ step.subtext }}”
              </p>
              <p class="text-sm text-navy-600 leading-relaxed">
                {{ step.description }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 6. REASSURANCE & PARENT INFORMATION                                 -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section id="parents" class="py-20 lg:py-28 bg-gradient-to-b from-purple-50/50 to-white border-b border-navy-100">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div class="lg:col-span-5 space-y-6">
            <span class="text-xs font-bold text-purple-700 uppercase tracking-widest bg-purple-100/80 px-3 py-1 rounded-full">
              For Parents &amp; Guardians
            </span>
            <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
              Clear reassurance and transparent communication.
            </h2>
            <p class="text-base text-navy-700 leading-relaxed">
              We know introducing your child to coding is an investment in their future. Here is how we ensure their experience is safe, constructive, and inspiring.
            </p>

            <ul class="space-y-4 text-sm text-navy-800">
              <li class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <UIcon name="i-lucide-check" class="w-4 h-4" />
                </div>
                <div>
                  <strong class="font-bold text-navy-950">Safe, Supervised Spaces:</strong>
                  Every venue, including our camp at Maktaba Kuu in Upper Hill, adheres to vetted child safety standards.
                </div>
              </li>
              <li class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <UIcon name="i-lucide-check" class="w-4 h-4" />
                </div>
                <div>
                  <strong class="font-bold text-navy-950">Evidence-Based Growth:</strong>
                  We track project mastery, technical competencies, and values observations without stressful exams.
                </div>
              </li>
              <li class="flex items-start gap-3">
                <div class="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <UIcon name="i-lucide-check" class="w-4 h-4" />
                </div>
                <div>
                  <strong class="font-bold text-navy-950">Dedicated Educator Mentors:</strong>
                  Our instructors are passionate technologists trained to nurture problem-solving patience and agency.
                </div>
              </li>
            </ul>
          </div>

          <!-- Highlight card -->
          <div class="lg:col-span-7">
            <div class="rounded-3xl p-8 bg-white border-2 border-navy-100 shadow-xl space-y-6">
              <h3 class="text-xl font-heading font-bold text-navy-950 flex items-center gap-2">
                <UIcon name="i-lucide-shield-check" class="w-6 h-6 text-yellow-500" />
                What you can always count on:
              </h3>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div class="p-4 rounded-2xl bg-navy-50/60 border border-navy-100">
                  <span class="font-bold text-navy-900 block mb-1">No Invented Urgency</span>
                  <span class="text-navy-600 text-xs">Schedules, dates, and availability are always tied directly to our real database.</span>
                </div>
                <div class="p-4 rounded-2xl bg-navy-50/60 border border-navy-100">
                  <span class="font-bold text-navy-900 block mb-1">Authentic Feedback</span>
                  <span class="text-navy-600 text-xs">Routine teacher feedback is released directly to authorized parents once reviewed.</span>
                </div>
                <div class="p-4 rounded-2xl bg-navy-50/60 border border-navy-100">
                  <span class="font-bold text-navy-900 block mb-1">Inclusive Pace</span>
                  <span class="text-navy-600 text-xs">Every learner receives personalized project challenges suited to their readiness.</span>
                </div>
                <div class="p-4 rounded-2xl bg-navy-50/60 border border-navy-100">
                  <span class="font-bold text-navy-900 block mb-1">Direct Contact</span>
                  <span class="text-navy-600 text-xs">Direct access to team coordinators at hello@jengacode.tech or +254 792 696 592.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 7. THE APPLICATION JOURNEY                                          -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section class="py-20 lg:py-28 bg-white border-b border-navy-100">
      <div class="max-w-7xl mx-auto px-5 lg:px-8">
        <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span class="text-xs font-bold text-purple-700 uppercase tracking-widest bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Simple &amp; Transparent Admissions
          </span>
          <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
            How the application process works.
          </h2>
          <p class="text-base text-navy-600">
            We distinguish each stage so you always know where your application stands.
          </p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div
            v-for="stg in applicationStages"
            :key="stg.step"
            class="relative rounded-3xl p-6 bg-white border-2 border-navy-100 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div class="w-10 h-10 rounded-full bg-purple-600 text-white font-mono font-bold flex items-center justify-center mb-4">
                {{ stg.step }}
              </div>
              <h3 class="text-lg font-heading font-bold text-navy-950 mb-2">
                {{ stg.title }}
              </h3>
              <p class="text-sm text-navy-600 leading-relaxed">
                {{ stg.desc }}
              </p>
            </div>
          </div>
        </div>

        <div class="mt-12 text-center">
          <NuxtLink to="/programs">
            <UButton size="xl" class="bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-full px-8 py-3.5 shadow-md">
              Start by Exploring Programs
            </UButton>
          </NuxtLink>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <!-- 8. FREQUENTLY ASKED QUESTIONS                                       -->
    <!-- ═══════════════════════════════════════════════════════════════════ -->
    <section id="faq" class="py-20 lg:py-28 bg-navy-50/50">
      <div class="max-w-4xl mx-auto px-5 lg:px-8">
        <div class="text-center mb-14 space-y-3">
          <span class="text-xs font-bold text-pink-600 uppercase tracking-widest bg-pink-50 px-3 py-1 rounded-full border border-pink-200">
            Got Questions?
          </span>
          <h2 class="text-3xl sm:text-4xl font-heading font-black text-navy-950">
            Frequently Asked Questions
          </h2>
        </div>

        <div class="space-y-4">
          <div
            v-for="(faq, i) in faqs"
            :key="i"
            class="rounded-2xl bg-white border border-navy-100 p-6 shadow-sm space-y-2"
          >
            <h3 class="text-base sm:text-lg font-heading font-bold text-navy-950">
              {{ faq.q }}
            </h3>
            <p class="text-sm text-navy-700 leading-relaxed">
              {{ faq.a }}
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
