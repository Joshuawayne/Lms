/**
 * Jjenga Code — Image Manifest & Asset Registry
 *
 * Provides typed access to licensed CDN photography, required attributions,
 * responsive dimensions and SVG fallback placeholders.
 *
 * Rule: Stock photographs are illustrative only and never attributed as
 * specific Jjenga Code learners, staff, or student project submissions.
 */

export interface BrandImage {
  readonly key: string
  readonly url: string
  readonly alt: string
  readonly photographer: string
  readonly photographerHandle: string
  readonly sourceUrl: string
  readonly license: string
  readonly width: number
  readonly height: number
}

export type BrandImageKey =
  | 'hero'
  | 'school_term'
  | 'saturday_club'
  | 'holiday_camp'
  | 'making_robotics'
  | 'electronics'

export const BRAND_IMAGES: Record<BrandImageKey, BrandImage> = {
  hero: {
    key: 'hero',
    url: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=1200&q=80',
    alt: 'Young student focusing on practical engineering and technology project',
    photographer: 'ThisisEngineering RAEng',
    photographerHandle: '@thisisengineering',
    sourceUrl: 'https://unsplash.com/photos/woman-in-white-dress-shirt-using-laptop-computer-1581092921461-eab62e97a780',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
  school_term: {
    key: 'school_term',
    url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=80',
    alt: 'Learners collaborating in a modern classroom technology environment',
    photographer: 'Stem.T4L',
    photographerHandle: '@stemt4l',
    sourceUrl: 'https://unsplash.com/photos/group-of-people-sitting-indoors-1509062522246-3755977927d7',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
  saturday_club: {
    key: 'saturday_club',
    url: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
    alt: 'Hands-on robotics kit being assembled and tested by a young builder',
    photographer: 'Robo Wunderkind',
    photographerHandle: '@robowunderkind',
    sourceUrl: 'https://unsplash.com/photos/person-holding-black-and-red-gadget-1577495508048-b635879837f1',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
  holiday_camp: {
    key: 'holiday_camp',
    url: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80',
    alt: 'Collaborative project team programming and discussing creative digital solutions',
    photographer: 'John Schnobrich',
    photographerHandle: '@johnschno',
    sourceUrl: 'https://unsplash.com/photos/person-using-macbook-pro-1516321318423-f06f85e504b3',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
  making_robotics: {
    key: 'making_robotics',
    url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1200&q=80',
    alt: 'Programmable robotics hardware with motion sensors',
    photographer: 'Alex Knight',
    photographerHandle: '@agkdesign',
    sourceUrl: 'https://unsplash.com/photos/white-robot-near-white-wall-1485827404703-89b55fcc595e',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
  electronics: {
    key: 'electronics',
    url: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?auto=format&fit=crop&w=1200&q=80',
    alt: 'Microcontroller board with breadboard wiring and LEDs',
    photographer: 'Alexandre Debiève',
    photographerHandle: '@alexandre_debieve',
    sourceUrl: 'https://unsplash.com/photos/close-up-photography-of-circuit-board-1517077304055-6e89abbf09b0',
    license: 'Unsplash License',
    width: 1200,
    height: 800,
  },
}

/**
 * Returns a clean SVG data URL fallback placeholder with retro pixel geometry.
 */
export function getPlaceholderSvg(label: string = 'Jjenga Code'): string {
  const escaped = label.replace(/[<>&"]/g, '')
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="none">
    <rect width="600" height="400" fill="#160D35"/>
    <circle cx="500" cy="80" r="140" fill="#8C2ACA" fill-opacity="0.3"/>
    <rect x="40" y="280" width="100" height="100" rx="20" fill="#F9C41D" fill-opacity="0.2"/>
    <text x="300" y="200" fill="#FFFFFF" font-family="system-ui, sans-serif" font-weight="700" font-size="24" text-anchor="middle" dominant-baseline="middle">${escaped}</text>
    <text x="300" y="235" fill="#F9C41D" font-family="system-ui, sans-serif" font-weight="500" font-size="14" text-anchor="middle" dominant-baseline="middle">Practical Coding &amp; Robotics</text>
  </svg>`
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`
}
