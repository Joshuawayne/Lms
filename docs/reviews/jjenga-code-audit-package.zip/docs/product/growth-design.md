# Growth support across the system

Use meaningful choices, achievable challenges, progressive support, collaboration,
reflection, retrieval and application to authentic problems. Feedback should name
a useful strategy and a concrete next step. Normalize debugging and revision.

Learners compare current work with their own earlier work and practice transfer.
Teachers receive optional contextual support and private reflection opportunities.
Parents receive constructive prompts linked to their child's actual work.
Administrators gain confidence through understandable previews, errors and recovery.

Start with explicit, testable guidance rules. Assess evidence quality separately from
readiness. Account for missing observations, interrupted attempts and access barriers.
Explain suggestions and allow appropriate overrides. Evaluate learning, independence,
fairness, transfer and teacher workload; engagement time alone is not success.

Users should understand what is recorded and who can see it. Avoid covert psychological
profiles, pressure to remain online, public character rankings, and automatic moral
judgments. The design supports growth; the scaffold does not implement or validate
an adaptive learning model yet.
