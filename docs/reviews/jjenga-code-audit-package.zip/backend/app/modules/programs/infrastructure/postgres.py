"""PostgreSQL repository implementations for programs and applications using psycopg.

Implements ProgramRepository and ApplicationRepository targeting the private
'lms' schema with RLS and the 'lms_api' role.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from datetime import datetime
from typing import Any

import psycopg
from psycopg.rows import dict_row

from app.modules.programs.application.errors import (
    ApplicationsClosedError,
    IdempotencyConflictError,
)
from app.modules.programs.application.ports import (
    ApplicationReplayRecord,
    ApplicationRepository,
    ApplicationSubmission,
    ProgramRepository,
    SubmissionResult,
)
from app.modules.programs.domain.entities import Program
from app.modules.programs.domain.values import (
    ApplicationStatus,
    Pathway,
    ProgramDelivery,
    ProgramStatus,
)

AsyncConnectionFactory = Callable[[], AbstractAsyncContextManager[psycopg.AsyncConnection[Any]]]


def _row_to_program(row: dict[str, Any]) -> Program:
    return Program(
        id=row["id"],
        pathway=Pathway(row["pathway"]),
        title=row["title"],
        slug=row["slug"],
        summary=row["summary"],
        description=row["description"],
        delivery=ProgramDelivery(row["delivery"]),
        status=ProgramStatus(row["status"]),
        applications_enabled=row["applications_enabled"],
        applications_open_at=row["applications_open_at"],
        applications_close_at=row["applications_close_at"],
        starts_on=row["starts_on"],
        ends_on=row["ends_on"],
        max_enrolments=row["max_enrolments"],
        min_age_years=row["min_age_years"],
        max_age_years=row["max_age_years"],
        display_order=row["display_order"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _row_to_replay_record(row: dict[str, Any]) -> ApplicationReplayRecord:
    return ApplicationReplayRecord(
        id=row["id"],
        idempotency_key=row["idempotency_key"],
        request_fingerprint=row["request_fingerprint"],
        program_id=row["program_id"],
        status=ApplicationStatus(row["status"]),
        submitted_at=row["submitted_at"],
        reference=row["reference"],
    )


class PostgresProgramRepository(ProgramRepository):
    """PostgreSQL implementation of ProgramRepository."""

    def __init__(self, connection_factory: AsyncConnectionFactory) -> None:
        self._connection_factory = connection_factory

    async def list_published(
        self,
        *,
        pathway: Pathway | None = None,
        page: int = 1,
        page_size: int = 12,
    ) -> tuple[list[Program], int]:
        offset = (page - 1) * page_size
        async with (
            self._connection_factory() as conn,
            conn.cursor(row_factory=dict_row) as cur,
        ):
            if pathway is not None:
                count_query = (
                    "SELECT count(*) AS total FROM lms.programs "
                    "WHERE status = 'published' AND pathway = %(pathway)s"
                )
                params: dict[str, Any] = {"pathway": pathway.value}
            else:
                count_query = (
                    "SELECT count(*) AS total FROM lms.programs WHERE status = 'published'"
                )
                params = {}

            await cur.execute(count_query, params)
            count_row = await cur.fetchone()
            total = count_row["total"] if count_row else 0

            list_query = (
                "SELECT id, pathway, title, slug, summary, description, delivery, status, "
                "applications_enabled, applications_open_at, applications_close_at, "
                "starts_on, ends_on, max_enrolments, min_age_years, max_age_years, "
                "display_order, created_at, updated_at "
                "FROM lms.programs "
                "WHERE status = 'published' "
                + ("AND pathway = %(pathway)s " if pathway is not None else "")
                + "ORDER BY display_order ASC, created_at ASC "
                "LIMIT %(limit)s OFFSET %(offset)s"
            )
            params["limit"] = page_size
            params["offset"] = offset

            await cur.execute(list_query, params)
            rows = await cur.fetchall()
            return [_row_to_program(row) for row in rows], total

    async def get_published_by_id(self, program_id: uuid.UUID) -> Program | None:
        async with (
            self._connection_factory() as conn,
            conn.cursor(row_factory=dict_row) as cur,
        ):
            await cur.execute(
                "SELECT id, pathway, title, slug, summary, description, delivery, status, "
                "applications_enabled, applications_open_at, applications_close_at, "
                "starts_on, ends_on, max_enrolments, min_age_years, max_age_years, "
                "display_order, created_at, updated_at "
                "FROM lms.programs WHERE id = %(id)s AND status = 'published'",
                {"id": program_id},
            )
            row = await cur.fetchone()
            return _row_to_program(row) if row else None

    async def get_by_slug(self, slug: str) -> Program | None:
        async with (
            self._connection_factory() as conn,
            conn.cursor(row_factory=dict_row) as cur,
        ):
            await cur.execute(
                "SELECT id, pathway, title, slug, summary, description, delivery, status, "
                "applications_enabled, applications_open_at, applications_close_at, "
                "starts_on, ends_on, max_enrolments, min_age_years, max_age_years, "
                "display_order, created_at, updated_at "
                "FROM lms.programs WHERE slug = %(slug)s AND status = 'published'",
                {"slug": slug},
            )
            row = await cur.fetchone()
            return _row_to_program(row) if row else None


class PostgresApplicationRepository(ApplicationRepository):
    """PostgreSQL implementation of ApplicationRepository."""

    def __init__(self, connection_factory: AsyncConnectionFactory) -> None:
        self._connection_factory = connection_factory

    async def get_current_time(self) -> datetime:
        async with (
            self._connection_factory() as conn,
            conn.cursor() as cur,
        ):
            await cur.execute("SELECT now()")
            row = await cur.fetchone()
            if row is None or not isinstance(row[0], datetime):
                msg = "Unable to fetch current timestamp from database"
                raise RuntimeError(msg)
            return row[0]

    async def find_by_idempotency_key(
        self, key: uuid.UUID
    ) -> ApplicationReplayRecord | None:
        async with (
            self._connection_factory() as conn,
            conn.cursor(row_factory=dict_row) as cur,
        ):
            await cur.execute(
                "SELECT id, idempotency_key, request_fingerprint, program_id, "
                "status, submitted_at, reference "
                "FROM lms.enrolment_applications WHERE idempotency_key = %(key)s",
                {"key": key},
            )
            row = await cur.fetchone()
            return _row_to_replay_record(row) if row else None

    async def insert_application(
        self, submission: ApplicationSubmission
    ) -> SubmissionResult:
        async with (
            self._connection_factory() as conn,
            conn.transaction(),
            conn.cursor(row_factory=dict_row) as cur,
        ):
            insert_query = (
                "INSERT INTO lms.enrolment_applications ("
                "idempotency_key, request_fingerprint, program_id, "
                "guardian_name, guardian_email, guardian_phone, guardian_relationship, "
                "learner_name, learner_age_years, notes, declaration_version, reference"
                ") "
                "SELECT "
                "%(idempotency_key)s, %(request_fingerprint)s, p.id, "
                "%(guardian_name)s, %(guardian_email)s, %(guardian_phone)s, "
                "%(guardian_relationship)s, %(learner_name)s, %(learner_age_years)s, "
                "%(notes)s, %(declaration_version)s, %(reference)s "
                "FROM lms.programs p "
                "WHERE p.id = %(program_id)s "
                "  AND p.status = 'published' "
                "  AND p.applications_enabled = true "
                "  AND (p.applications_open_at IS NULL OR now() >= p.applications_open_at) "
                "  AND (p.applications_close_at IS NULL OR now() < p.applications_close_at) "
                "ON CONFLICT (idempotency_key) DO NOTHING "
                "RETURNING id, idempotency_key, request_fingerprint, program_id, "
                "status, submitted_at, reference"
            )
            params = {
                "idempotency_key": submission.idempotency_key,
                "request_fingerprint": submission.request_fingerprint,
                "program_id": submission.program_id,
                "guardian_name": submission.guardian_name,
                "guardian_email": submission.guardian_email,
                "guardian_phone": submission.guardian_phone,
                "guardian_relationship": submission.guardian_relationship.value,
                "learner_name": submission.learner_name,
                "learner_age_years": submission.learner_age_years,
                "notes": submission.notes,
                "declaration_version": submission.declaration_version,
                "reference": submission.reference,
            }
            await cur.execute(insert_query, params)
            row = await cur.fetchone()

            if row is not None:
                record = _row_to_replay_record(row)
                audit_query = (
                    "INSERT INTO lms.application_audit_events ("
                    "application_id, event_type, actor_id, detail"
                    ") VALUES (%(application_id)s, 'submitted', NULL, NULL)"
                )
                await cur.execute(audit_query, {"application_id": record.id})
                return SubmissionResult(record=record, is_new=True)

            # Concurrency race or program closed: check for existing row with this idempotency key
            await cur.execute(
                "SELECT id, idempotency_key, request_fingerprint, program_id, "
                "status, submitted_at, reference "
                "FROM lms.enrolment_applications WHERE idempotency_key = %(key)s",
                {"key": submission.idempotency_key},
            )
            existing_row = await cur.fetchone()
            if existing_row is not None:
                existing_record = _row_to_replay_record(existing_row)
                if existing_record.request_fingerprint == submission.request_fingerprint:
                    return SubmissionResult(record=existing_record, is_new=False)
                raise IdempotencyConflictError()

            # No existing application found: program was not eligible / applications closed
            raise ApplicationsClosedError(
                "The program is not currently published or open for applications."
            )
