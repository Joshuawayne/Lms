"""Database integration tests targeting PostgreSQL with the restricted lms_api role.

These tests run against a live PostgreSQL database when LMS_TEST_DATABASE_URL
or LMS_DATABASE_URL is provided. If no live database is configured, these tests
are skipped with explicit reporting.
"""

from __future__ import annotations

import asyncio
import os
import sys
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import psycopg
import pytest
from psycopg.errors import InsufficientPrivilege
from psycopg.rows import dict_row

from app.modules.programs.application.commands import compute_payload_fingerprint
from app.modules.programs.application.errors import (
    ApplicationsClosedError,
    IdempotencyConflictError,
)
from app.modules.programs.application.ports import ApplicationSubmission
from app.modules.programs.domain.values import GuardianRelationship
from app.modules.programs.infrastructure.postgres import PostgresApplicationRepository

# On Windows, psycopg async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

TEST_DB_URL = (
    os.environ.get("LMS_TEST_DATABASE_URL")
    or os.environ.get("TEST_DATABASE_URL")
    or os.environ.get("LMS_DATABASE_URL")
)
MAINT_DB_URL = os.environ.get("LMS_MIGRATION_DATABASE_URL") or TEST_DB_URL

pytestmark = pytest.mark.skipif(
    not TEST_DB_URL,
    reason=(
        "Live PostgreSQL database URL not configured (set LMS_TEST_DATABASE_URL). "
        "Database-backed RLS and concurrency checks remain unverified in local mock environment."
    ),
)


@asynccontextmanager
async def _make_api_connection() -> AsyncIterator[psycopg.AsyncConnection[Any]]:
    """Open a separate PostgreSQL connection under the restricted lms_api role.

    Autocommit=True ensures SET ROLE does not leave an open transaction,
    allowing repository-level transactions to control commit boundaries.
    """
    assert TEST_DB_URL is not None
    conn = await psycopg.AsyncConnection.connect(TEST_DB_URL, autocommit=True)
    try:
        await conn.execute("SET ROLE lms_api;")
        yield conn
    finally:
        await conn.close()


@asynccontextmanager
async def _make_maint_connection() -> AsyncIterator[psycopg.AsyncConnection[Any]]:
    """Open a maintenance connection for test fixture setup and privileged assertions."""
    assert MAINT_DB_URL is not None
    conn = await psycopg.AsyncConnection.connect(MAINT_DB_URL, autocommit=True)
    try:
        yield conn
    finally:
        await conn.close()


def _make_connection_factory() -> Any:
    return _make_api_connection


def _sample_submission(
    program_id: uuid.UUID,
    *,
    idempotency_key: uuid.UUID | None = None,
    guardian_name: str = "Test Guardian",
    guardian_email: str = "guardian@example.com",
    guardian_phone: str | None = "+254700000000",
    guardian_relationship: GuardianRelationship = GuardianRelationship.PARENT,
    learner_name: str = "Test Learner",
    learner_age_years: int = 10,
    notes: str | None = "Testing integration",
    declaration_version: int = 1,
) -> ApplicationSubmission:
    key = idempotency_key or uuid.uuid4()
    ref_suffix = str(key)[:8]
    fingerprint = compute_payload_fingerprint(
        program_id=program_id,
        guardian_name=guardian_name,
        guardian_email=guardian_email,
        guardian_phone=guardian_phone,
        guardian_relationship=guardian_relationship,
        learner_name=learner_name,
        learner_age_years=learner_age_years,
        notes=notes,
        declaration_version=declaration_version,
    )
    return ApplicationSubmission(
        idempotency_key=key,
        request_fingerprint=fingerprint,
        program_id=program_id,
        guardian_name=guardian_name,
        guardian_email=guardian_email,
        guardian_phone=guardian_phone,
        guardian_relationship=guardian_relationship,
        learner_name=learner_name,
        learner_age_years=learner_age_years,
        notes=notes,
        declaration_version=declaration_version,
        reference=f"APP-TEST-{ref_suffix}",
    )


@pytest.mark.anyio
async def test_denied_access_to_personal_columns() -> None:
    """The restricted lms_api role must be denied SELECT access to personal contact columns."""
    async with _make_api_connection() as conn, conn.cursor() as cur:
        with pytest.raises(InsufficientPrivilege):
            await cur.execute(
                "SELECT guardian_email, guardian_phone, learner_name "
                "FROM lms.enrolment_applications LIMIT 1"
            )


@pytest.mark.anyio
async def test_denied_draft_disabled_and_out_of_window_submissions() -> None:
    """Submissions to real draft, disabled, future or expired programs must be rejected by RLS."""
    repo = PostgresApplicationRepository(_make_connection_factory())

    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        # Create 4 fixture programs in distinct non-submittable states
        test_slug_prefix = f"test-denied-{uuid.uuid4().hex[:6]}"

        # 1. Draft program
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'school_term', 'Draft Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'draft', true, now() - interval '1 day', now() + interval '10 days',
                '2027-01-01', '2027-04-01', 7, 17, 100
            ) RETURNING id
            """,
            {"slug": f"{test_slug_prefix}-draft"},
        )
        draft_row = await m_cur.fetchone()
        assert draft_row is not None
        draft_id = draft_row["id"]

        # 2. Disabled program (published, but applications_enabled = false)
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'saturday_club', 'Disabled Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', false, now() - interval '1 day', now() + interval '10 days',
                '2027-01-01', '2027-04-01', 7, 17, 101
            ) RETURNING id
            """,
            {"slug": f"{test_slug_prefix}-disabled"},
        )
        disabled_row = await m_cur.fetchone()
        assert disabled_row is not None
        disabled_id = disabled_row["id"]

        # 3. Future window program (published, enabled, but window not yet open)
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'holiday', 'Future Window Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() + interval '5 days', now() + interval '20 days',
                '2027-01-01', '2027-04-01', 7, 17, 102
            ) RETURNING id
            """,
            {"slug": f"{test_slug_prefix}-future"},
        )
        future_row = await m_cur.fetchone()
        assert future_row is not None
        future_id = future_row["id"]

        # 4. Expired window program (published, enabled, but window closed in past)
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'holiday', 'Expired Window Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() - interval '20 days', now() - interval '1 day',
                '2027-01-01', '2027-04-01', 7, 17, 103
            ) RETURNING id
            """,
            {"slug": f"{test_slug_prefix}-expired"},
        )
        expired_row = await m_cur.fetchone()
        assert expired_row is not None
        expired_id = expired_row["id"]

    # Verify that each real non-submittable state is rejected
    for prog_id in [draft_id, disabled_id, future_id, expired_id]:
        sub = _sample_submission(prog_id)
        with pytest.raises(ApplicationsClosedError):
            await repo.insert_application(sub)


@pytest.mark.anyio
async def test_denied_approved_status_submissions_and_admin_audit_events() -> None:
    """lms_api cannot insert applications with status='approved' or review audit events."""
    async with _make_api_connection() as conn:
        # 1. Attempt to insert an application with approved status
        fake_key = uuid.uuid4()
        fake_prog_id = uuid.uuid4()
        app_insert_query = (
            "INSERT INTO lms.enrolment_applications ("
            "idempotency_key, request_fingerprint, program_id, guardian_name, "
            "guardian_email, guardian_relationship, learner_name, learner_age_years, "
            "declaration_version, reference, status"
            ") VALUES ("
            "%s, %s, %s, 'G', 'g@example.com', 'parent', 'L', 10, 1, 'REF-TEST', 'approved'"
            ")"
        )
        app_params = (fake_key, "a" * 64, fake_prog_id)
        with pytest.raises(psycopg.Error):
            async with conn.cursor() as cur:
                await cur.execute(app_insert_query, app_params)

        # 2. Attempt to insert an audit event with event_type='under_review' or non-null actor
        fake_app_id = uuid.uuid4()
        fake_actor_id = uuid.uuid4()
        audit_insert_query = (
            "INSERT INTO lms.application_audit_events ("
            "application_id, event_type, actor_id"
            ") VALUES (%s, 'under_review', %s)"
        )
        audit_params = (fake_app_id, fake_actor_id)
        with pytest.raises(psycopg.Error):
            async with conn.cursor() as cur:
                await cur.execute(audit_insert_query, audit_params)


@pytest.mark.anyio
async def test_matching_and_conflicting_idempotent_retries() -> None:
    """Matching fingerprint replays receipt; conflicting fingerprint raises error."""
    repo = PostgresApplicationRepository(_make_connection_factory())

    # Ensure an active open program exists
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        slug = f"test-retry-flow-{uuid.uuid4().hex[:6]}"
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'saturday_club', 'Open Test Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() - interval '1 hour', now() + interval '10 days',
                '2027-01-01', '2027-04-01', 7, 17, 1
            ) RETURNING id
            """,
            {"slug": slug},
        )
        row = await m_cur.fetchone()
        assert row is not None
        program_id = row["id"]

    key = uuid.uuid4()
    submission1 = _sample_submission(program_id, idempotency_key=key)

    res1 = await repo.insert_application(submission1)
    assert res1.is_new is True

    # Matching retry
    res2 = await repo.insert_application(submission1)
    assert res2.is_new is False
    assert res2.record.id == res1.record.id
    assert res2.record.reference == res1.record.reference

    # Conflicting retry with same key but different fingerprint
    submission_conflict = _sample_submission(
        program_id,
        idempotency_key=key,
        learner_name="Other Name",
        notes="different notes",
    )
    with pytest.raises(IdempotencyConflictError):
        await repo.insert_application(submission_conflict)


@pytest.mark.anyio
async def test_replay_after_application_closure() -> None:
    """An application submitted while open can still be replayed after the window closes."""
    repo = PostgresApplicationRepository(_make_connection_factory())

    # 1. Create a published, open program via maintenance connection
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        slug = f"test-closure-replay-{uuid.uuid4().hex[:6]}"
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'holiday', 'Camp To Close', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() - interval '2 hours', now() + interval '2 hours',
                '2026-12-01', '2026-12-05', 7, 17, 1
            ) RETURNING id
            """,
            {"slug": slug},
        )
        row = await m_cur.fetchone()
        assert row is not None
        program_id = row["id"]

    # 2. Submit initial application while program is open
    key = uuid.uuid4()
    sub = _sample_submission(program_id, idempotency_key=key)
    res1 = await repo.insert_application(sub)
    assert res1.is_new is True

    # 3. Close the program in the database
    async with _make_maint_connection() as m_conn, m_conn.cursor() as m_cur:
        await m_cur.execute(
            """
            UPDATE lms.programs
            SET applications_enabled = false,
                applications_close_at = now() - interval '1 hour'
            WHERE id = %s
            """,
            (program_id,),
        )

    # 4. Replay the same submission: must succeed and return original receipt
    res2 = await repo.insert_application(sub)
    assert res2.is_new is False
    assert res2.record.id == res1.record.id
    assert res2.record.reference == res1.record.reference

    # 5. Conflicting payload with existing key on closed program raises conflict
    conflicting_sub = _sample_submission(
        program_id, idempotency_key=key, notes="altered after close"
    )
    with pytest.raises(IdempotencyConflictError):
        await repo.insert_application(conflicting_sub)

    # 6. New submission with new key to closed program raises ApplicationsClosedError
    new_key = uuid.uuid4()
    new_sub = _sample_submission(program_id, idempotency_key=new_key)
    with pytest.raises(ApplicationsClosedError):
        await repo.insert_application(new_sub)


@pytest.mark.anyio
async def test_concurrent_submissions_producing_one_application_and_one_submission_event() -> None:
    """Concurrent submissions across separate connections produce 1 application and 1 event."""
    # Create an open program
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        slug = f"test-concurrent-{uuid.uuid4().hex[:6]}"
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'school_term', 'Concurrent Test Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() - interval '1 hour', now() + interval '10 days',
                '2027-01-01', '2027-04-01', 7, 17, 1
            ) RETURNING id
            """,
            {"slug": slug},
        )
        row = await m_cur.fetchone()
        assert row is not None
        program_id = row["id"]

    key = uuid.uuid4()
    submission = _sample_submission(program_id, idempotency_key=key)

    # Create two distinct repositories each using its own connection
    repo1 = PostgresApplicationRepository(_make_connection_factory())
    repo2 = PostgresApplicationRepository(_make_connection_factory())

    results = await asyncio.gather(
        repo1.insert_application(submission),
        repo2.insert_application(submission),
        return_exceptions=True,
    )

    successes = [r for r in results if not isinstance(r, BaseException)]
    assert len(successes) == 2, f"Expected 2 successful responses, got {results}"

    # Verify atomic insertion via maintenance connection
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        # Exactly 1 application row exists
        await m_cur.execute(
            "SELECT count(*) AS total FROM lms.enrolment_applications WHERE idempotency_key = %s",
            (key,),
        )
        app_row = await m_cur.fetchone()
        assert app_row is not None
        assert app_row["total"] == 1

        # Exactly 1 audit event exists
        await m_cur.execute(
            "SELECT count(*) AS total FROM lms.application_audit_events WHERE application_id = %s",
            (successes[0].record.id,),
        )
        audit_row = await m_cur.fetchone()
        assert audit_row is not None
        assert audit_row["total"] == 1


@pytest.mark.anyio
async def test_application_rollback_when_audit_insertion_fails() -> None:
    """If the audit event insert fails, the application insert is rolled back completely."""
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        slug = f"test-rollback-{uuid.uuid4().hex[:6]}"
        await m_cur.execute(
            """
            INSERT INTO lms.programs (
                pathway, title, slug, summary, description, delivery, status,
                applications_enabled, applications_open_at, applications_close_at,
                starts_on, ends_on, min_age_years, max_age_years, display_order
            ) VALUES (
                'school_term', 'Rollback Test Program', %(slug)s, 'Summary', 'Desc', 'in_person',
                'published', true, now() - interval '1 hour', now() + interval '10 days',
                '2027-01-01', '2027-04-01', 7, 17, 1
            ) RETURNING id
            """,
            {"slug": slug},
        )
        row = await m_cur.fetchone()
        assert row is not None
        program_id = row["id"]

    test_key = uuid.uuid4()
    test_ref = f"APP-ROLLBACK-{str(test_key)[:8]}"

    # Deliberately perform a two-step transaction where step 2 fails
    async with (
        _make_api_connection() as conn,
    ):
        with pytest.raises(psycopg.Error):
            async with conn.transaction(), conn.cursor() as cur:
                # Step 1: Insert application
                await cur.execute(
                    """
                    INSERT INTO lms.enrolment_applications (
                        idempotency_key, request_fingerprint, program_id,
                        guardian_name, guardian_email, guardian_relationship,
                        learner_name, learner_age_years, declaration_version, reference
                    ) VALUES (
                        %(idempotency_key)s, %(request_fingerprint)s, %(program_id)s,
                        'Parent', 'parent@example.com', 'parent',
                        'Learner', 10, 1, %(reference)s
                    ) RETURNING id
                    """,
                    {
                        "idempotency_key": test_key,
                        "request_fingerprint": "b" * 64,
                        "program_id": program_id,
                        "reference": test_ref,
                    },
                )
                app_res = await cur.fetchone()
                assert app_res is not None
                app_id = app_res[0]

                # Step 2: Deliberately fail audit insert by violating actor_id IS NULL constraint
                invalid_actor = uuid.uuid4()
                await cur.execute(
                    """
                    INSERT INTO lms.application_audit_events (
                        application_id, event_type, actor_id
                    ) VALUES (%(app_id)s, 'submitted', %(actor_id)s)
                    """,
                    {"app_id": app_id, "actor_id": invalid_actor},
                )

    # Prove via separate maintenance connection that the application row was rolled back!
    async with _make_maint_connection() as m_conn, m_conn.cursor(row_factory=dict_row) as m_cur:
        await m_cur.execute(
            "SELECT count(*) AS total FROM lms.enrolment_applications WHERE idempotency_key = %s",
            (test_key,),
        )
        row = await m_cur.fetchone()
        assert row is not None
        assert row["total"] == 0, "Application row must be rolled back when audit insert fails!"
